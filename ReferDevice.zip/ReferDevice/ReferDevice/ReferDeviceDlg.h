
// ReferDeviceDlg.h : header file
//

#pragma once


// CReferDeviceDlg dialog
class CReferDeviceDlg : public CDialogEx
{
// Construction
public:
	CReferDeviceDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_REFERDEVICE_DIALOG };
#endif

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support


// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnRangeCmdsMemType(UINT nID);
	afx_msg void OnDevNameCheck();
	DECLARE_MESSAGE_MAP()
	//////
	bool m_bRBtp;
	CButton* pGrpMemType;
	CButton *btnPlc;
	CButton *btnTp;
	CButton *btnConst;

	CButton *m_chkDevNm;
	CComboBox *m_combDevNm;
	void OnPlc();
	void OnTp();
	void OnConst();
};
