
// ReferDeviceDlg.cpp : implementation file
//

#include "stdafx.h"
#include "ReferDevice.h"
#include "ReferDeviceDlg.h"
#include "afxdialogex.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CReferDeviceDlg dialog



CReferDeviceDlg::CReferDeviceDlg(CWnd* pParent /*=NULL*/)
	: CDialogEx(IDD_REFERDEVICE_DIALOG, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CReferDeviceDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CReferDeviceDlg, CDialogEx)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_COMMAND_RANGE(IDC_TP_PLC_RADIO, IDC_TP_CONST_RADIO, &CReferDeviceDlg::OnRangeCmdsMemType)
	ON_BN_CLICKED(IDC_TP_DEV_NAME_CHECK, OnDevNameCheck)
END_MESSAGE_MAP()


// CReferDeviceDlg message handlers

BOOL CReferDeviceDlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	// TODO: Add extra initialization here
	m_bRBtp = true;//clicked by operationDlg:true, by RefDevBtn: false
	UINT nRbItems = m_bRBtp ? 3 : 2;
	POINT ptLfTp = { 5,5 };
	SIZE szWH = { 200,120 };
	CRect rc(ptLfTp, szWH);
	pGrpMemType = new CButton;
	pGrpMemType->Create(_T(""), WS_CHILD | WS_VISIBLE | BS_GROUPBOX, rc, this, IDC_STATIC_MEM_TYPE);

	btnPlc = new CButton;
	btnTp = new CButton;
	btnConst = new CButton;

	int nMarginH = szWH.cy / nRbItems - 10;
	int nLftpX = ptLfTp.x + 10;
	int nLftpY = ptLfTp.y + (szWH.cy) / nRbItems - nMarginH;
	
	btnPlc->Create(L"&PLC",
		WS_GROUP | WS_VISIBLE | BS_AUTORADIOBUTTON,
		CRect(nLftpX, nLftpY, 200, nLftpY + nMarginH), this, IDC_TP_PLC_RADIO);

	if (m_bRBtp) {
		nLftpY += nMarginH;
		btnTp->Create(L"&TP",
			WS_CHILD | WS_VISIBLE | BS_AUTORADIOBUTTON,
			CRect(nLftpX, nLftpY, 200, nLftpY + nMarginH), this, IDC_TP_TP_RADIO);
	}

	nLftpY += nMarginH;
	btnConst->Create(L"&�`��",
		WS_CHILD | WS_VISIBLE | BS_AUTORADIOBUTTON,
		CRect(nLftpX, nLftpY, 200, nLftpY + nMarginH), this, IDC_TP_CONST_RADIO);

	//////
	m_chkDevNm = new CButton;
	m_combDevNm = new CComboBox;
	m_chkDevNm->SubclassDlgItem(IDC_TP_DEV_NAME_CHECK, this);
	m_combDevNm->SubclassDlgItem(IDC_TP_DEV_NAME_COMBO,this);
	return TRUE;
}

void CReferDeviceDlg::OnRangeCmdsMemType(UINT nID)
{
	switch (nID)
	{
	case IDC_TP_PLC_RADIO:
		OnPlc();
		break;
	case IDC_TP_TP_RADIO:
		OnTp();
		break;
	case IDC_TP_CONST_RADIO:
		OnConst();
		break;
	default:
		break;
	}
}

void CReferDeviceDlg::OnPlc()
{
	m_chkDevNm->SetCheck(TRUE);
	m_chkDevNm->EnableWindow(TRUE);
	//////
	CString szDevNameArr[] = {L"T", L"C", L"D"};
	m_combDevNm->ResetContent();
	UINT nLen = sizeof(szDevNameArr) / sizeof(szDevNameArr[0]);
	for (size_t i = 0; i < nLen; i++)
	{
		m_combDevNm->AddString(szDevNameArr[i]);
	}
	//////

}
void CReferDeviceDlg::OnTp()
{
	m_chkDevNm->SetCheck(TRUE);
	m_chkDevNm->EnableWindow(FALSE);
	//////
	m_combDevNm->ResetContent();
	m_combDevNm->AddString(L"@V");
	//////
}
void CReferDeviceDlg::OnConst()
{
	m_chkDevNm->SetCheck(FALSE);
	m_chkDevNm->EnableWindow(FALSE);
	//////
	m_combDevNm->ResetContent();
	m_combDevNm->EnableWindow(FALSE);
	//////
}
void CReferDeviceDlg::OnDevNameCheck()
{
	CButton *m_ctlCheck = (CButton*)GetDlgItem(IDC_TP_DEV_NAME_CHECK);
	int nChkBox = m_ctlCheck->GetCheck();
	CString str;

	if (nChkBox == BST_UNCHECKED)
		str.Format(_T("Un Checked"));
	else if (nChkBox == BST_CHECKED)
		str.Format(_T("Checked"));

	AfxMessageBox(str);
}
// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CReferDeviceDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialogEx::OnPaint();
	}
}

// The system calls this function to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CReferDeviceDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}

