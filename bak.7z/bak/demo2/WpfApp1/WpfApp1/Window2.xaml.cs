﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfApp1
{
    /// <summary>
    /// Window2.xaml 的互動邏輯
    /// </summary>
    public partial class Window2 : Window
    {
        TravelViewModel _travelViewModel;
        public Window2()
        {
            InitializeComponent();
            //this.lstItems.ItemsSource = GetItems();
            _travelViewModel = (TravelViewModel)base.DataContext;
            this.lstItems.ItemsSource = _travelViewModel.GetItems();
        }

        #region Properies

        #endregion


    }

    public class TravelViewModel : INotifyPropertyChanged
    {
        private CITYOPTION _selectedOption;
        public List<CITYOPTION> _availableOptions;

        /*Property as the View Binding*/
        //選定ComboBox下拉項目
        public CITYOPTION SelectedOption
        {
            get { return _selectedOption; }
            set {
                _selectedOption = value;
                RaisePropertyChanged("_selectedOption"); }
        }
        //ComboBox下拉的Data集
        public List<CITYOPTION> AvailableOptions
        {
            get { return _availableOptions; }
            set
            {
                _availableOptions = value;
                RaisePropertyChanged("_availableOptions");
            }
        }

        #region Methods
        //回傳給List<CITYOPTION> AvailableOptions, 並給ComboBox ItemsSource用
        private List<CITYOPTION> GetCityOptionItemsSource1()
        {
            //Add Taipei, Taichung到ComboBox(但全部有台北,台中,高雄)
            List<CITYOPTION> options = new List<CITYOPTION>();
            options.Add(CITYOPTION.Taipei);
            options.Add(CITYOPTION.Taichung);

            return options;
        }
        private List<CITYOPTION> GetCityOptionItemsSource2()
        {
            //Add Taipei, Taichung, Kaoshung到ComboBox
            List<CITYOPTION> options = new List<CITYOPTION>();
            options.Add(CITYOPTION.Taipei);
            options.Add(CITYOPTION.Taichung);
            options.Add(CITYOPTION.Kaoshung);

            return options;
        }
        #endregion

        //View 的GridView 設定要綁定N個下拉控件
        public List<TravelViewModel> GetItems()
        {
            //宣告並實體化物件集合
            List<TravelViewModel> items = new List<TravelViewModel>();
            //集合項目使用object initializer (設定ComboBox字面值呈現)
            items.Add(new TravelViewModel() { /*SelectedOption = CITYOPTION.Taipei,*/ AvailableOptions = GetCityOptionItemsSource1() });
            items.Add(new TravelViewModel() { SelectedOption = CITYOPTION.Taipei, AvailableOptions = GetCityOptionItemsSource2() });

            return items;
        }


        /*INotifyPropertyChanged介面實作*/
        public event PropertyChangedEventHandler PropertyChanged;
        //產生事件的方法
        private void RaisePropertyChanged(string propertyName)
        {
            PropertyChangedEventHandler handler = PropertyChanged;
            if (handler != null)
            {
                handler(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    }

    //All definitions
    public enum CITYOPTION
    {
        Taipei,
        Taichung,
        Kaoshung
    }
}
