#pragma once
#include "afxwin.h"


// CA01_DIALOG dialog

class CA01_DIALOG : public CDialogEx
{
	DECLARE_DYNAMIC(CA01_DIALOG)

public:
	CA01_DIALOG(CWnd* pParent = NULL);   // standard constructor
	virtual ~CA01_DIALOG();

// Dialog Data
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_A01_DIALOG };
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	CBrush m_redbrush, m_bluebrush;
	COLORREF m_redcolor, m_bluecolor, m_textcolor;
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedButton1();
	afx_msg void OnBnClickedOk();
	CEdit IDC_ED_VAL1;//�ϥ����O���F����
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
 
	virtual BOOL OnInitDialog();
};
