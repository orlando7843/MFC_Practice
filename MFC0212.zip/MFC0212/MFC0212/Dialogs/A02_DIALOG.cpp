// A02_DIALOG.cpp : ��@��
//

#include "stdafx.h"
#include "../MFC0212.h"
#include "A02_DIALOG.h"
#include "afxdialogex.h"
#include "../resource.h"


// CA02_DIALOG ��ܤ��

IMPLEMENT_DYNAMIC(CA02_DIALOG, CDialogEx)

CA02_DIALOG::CA02_DIALOG(CWnd* pParent /*=NULL*/)
	: CDialogEx(IDD_A02_DIALOG, pParent)
{
	
}

CA02_DIALOG::~CA02_DIALOG()
{
	KillTimer(ID_TIMER_MINUTE);
	KillTimer(ID_TIMER_SECONDS);
}

BOOL CA02_DIALOG::OnInitDialog()
{
	CDialog::OnInitDialog();

	// TODO: Add extra initialization here
	cnt = 0;
	SetTimer(ID_TIMER_MINUTE, 50, 0);
	//SetTimer(ID_TIMER_SECONDS, 0.001 * 1000, 0);

	return TRUE;  // return TRUE unless you set the focus to a control
				  // EXCEPTION: OCX Property Pages should return FALSE
}

void CA02_DIALOG::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CA02_DIALOG, CDialogEx)
	ON_WM_PAINT()
	ON_WM_TIMER()
	//ON_WM_ERASEBKGND()
	ON_CBN_SELCHANGE(IDC_COMBO1, &CA02_DIALOG::OnCbnSelchangeCombo1)
END_MESSAGE_MAP()


// CA02_DIALOG �T���B�z�`��
void CA02_DIALOG::OnPaint() 
{
	CPaintDC dc(this); // device context for painting  

	CRect  rect;
	GetClientRect(&rect);
	CDC  dcMem; 

	dcMem.CreateCompatibleDC(&dc);
	CBitmap  bmpBackground; 
	bmpBackground.LoadBitmap(IDB_BITMAP1); 
	BITMAP  bitmap;
	bmpBackground.GetBitmap(&bitmap); 
	CBitmap  *pbmpOld = dcMem.SelectObject(&bmpBackground);
	
	//�r���X
	CString strCnt;
	strCnt.Format(L"%d", cnt);
	dcMem.TextOutW(10,10, strCnt);
	
	dc.SetStretchBltMode(COLORONCOLOR);
	dc.StretchBlt(0, 0, rect.Width(), rect.Height(), &dcMem, 0, 0, bitmap.bmWidth, bitmap.bmHeight, SRCCOPY);

	dcMem.SelectObject(pbmpOld);
	bmpBackground.DeleteObject();
	dcMem.DeleteDC();
	
	CDialog::OnPaint();	

	//CPaintDC dc(this);
	//CWnd* pImage = GetDlgItem(IDC_PICTURE_CONTROL);
	//CRect rc;
	//pImage->GetWindowRect(rc);
	//HRGN hRgn = CreateRoundRectRgn(0, 0, rc.Width(), rc.Height(), 40, 40);
	//HINSTANCE hIns = AfxGetInstanceHandle();
	//HBITMAP hBmp = LoadBitmap(hIns, MAKEINTRESOURCE(IDB_BITMAP1));
	//HBRUSH hBr = CreatePatternBrush(hBmp);
	//DeleteObject(hIns);
	//DeleteObject(hBmp);
	//FillRgn(pImage->GetDC()->GetSafeHdc(), hRgn, hBr);
	//CDialog::OnPaint();
}

// Timer Handler.
void CA02_DIALOG::OnTimer(UINT nIDEvent)
{
	// Per minute timer ticked.
	if (nIDEvent == ID_TIMER_MINUTE)
	{
		// Do your minute based tasks here.
		++cnt;
		OnPaint();
	}

	// Per minute timer ticked.
	if (nIDEvent == ID_TIMER_SECONDS)
	{
		// Do your seconds based tasks here.
		cnt +=2;
		OnPaint();
	}
	//Invalidate();
	InvalidateRect(NULL);
}

//BOOL CA02_DIALOG::OnEraseBkgnd(CDC* pDC)
//{
//	// TODO: Add your message handler code here and/or call default
//	//return CWnd::OnEraseBkgnd(pDC);
//	return true;
//}

void CA02_DIALOG::OnCbnSelchangeCombo1()
{	
	CComboBox* combo = (CComboBox*)GetDlgItem(IDC_COMBO1);
	int nSelect = combo->GetCurSel();
	float elapse = 0;
	if(nSelect == 0)
		elapse = 50;
	else if (nSelect == 1)
		elapse = 100;
	else if (nSelect == 2)
		elapse = 200;
	else if (nSelect == 3)
		elapse = 300;
	else if (nSelect == 4)
		elapse = 400;
	else if (nSelect == 5)
		elapse = 500;
	else if (nSelect == 6)
		elapse = 600;
	SetTimer(ID_TIMER_MINUTE, elapse, 0);
}
