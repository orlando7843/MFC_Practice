#pragma once


// CA02_DIALOG ��ܤ��

class CA02_DIALOG : public CDialogEx
{
	DECLARE_DYNAMIC(CA02_DIALOG)

public:
	CA02_DIALOG(CWnd* pParent = NULL);   // �зǫغc�禡
	virtual ~CA02_DIALOG();

// ��ܤ�����
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_A02_DIALOG };
#endif

protected:
	virtual BOOL OnInitDialog();
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �䴩
	afx_msg void OnPaint();
	afx_msg void OnTimer(UINT nIDEvent);
	//afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	DECLARE_MESSAGE_MAP()
	int cnt;
	const UINT ID_TIMER_MINUTE = 0x1001;	
	const UINT ID_TIMER_SECONDS = 0x1002;
public:
	afx_msg void OnCbnSelchangeCombo1();
};
