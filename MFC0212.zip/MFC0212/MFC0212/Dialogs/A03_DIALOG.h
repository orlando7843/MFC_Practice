#pragma once


// CA03_DIALOG dialog

class CA03_DIALOG : public CDialogEx
{
	DECLARE_DYNAMIC(CA03_DIALOG)

public:
	CA03_DIALOG(CWnd* pParent = NULL);   // standard constructor
	virtual ~CA03_DIALOG();
	//virtual BOOL OnCommand(WPARAM wParam, LPARAM lParam);

// Dialog Data
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_A03_DIALOG };
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnContextMenu(CWnd* /*pWnd*/, CPoint /*point*/);
	afx_msg void MnuTpOprHandler(UINT nID);
	
	afx_msg void OnBnClickedOpBtn();
};
