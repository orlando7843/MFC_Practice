// A01_DIALOG.cpp : implementation file
//
#include "stdafx.h"
#include "../MFC0212.h"
#include "A01_DIALOG.h"
#include "afxdialogex.h"


// CA01_DIALOG dialog

IMPLEMENT_DYNAMIC(CA01_DIALOG, CDialogEx)

CA01_DIALOG::CA01_DIALOG(CWnd* pParent /*=NULL*/)
	: CDialogEx(IDD_A01_DIALOG, pParent)
{

}

CA01_DIALOG::~CA01_DIALOG()
{
}

void CA01_DIALOG::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	//���O���FID����match�����ܼ�
	DDX_Control(pDX, IDC_EDIT1, IDC_ED_VAL1);
}


BEGIN_MESSAGE_MAP(CA01_DIALOG, CDialogEx)	
	ON_BN_CLICKED(IDC_BUTTON1, &CA01_DIALOG::OnBnClickedButton1)
	ON_BN_CLICKED(IDOK, &CA01_DIALOG::OnBnClickedOk)
	ON_WM_CTLCOLOR()
END_MESSAGE_MAP()


// CA01_DIALOG message handlers


void CA01_DIALOG::OnBnClickedButton1()
{
	/*�g�JIDC_EDIT1���e*/
	//Way1�z�LGetDlgItem(����ѧO�X)
	CEdit* myEdit = (CEdit*)GetDlgItem(IDC_EDIT1);//�s�豱����w
	myEdit->SetWindowText(_T("HI"));

	//Way2�z�L�����ܼ�
	IDC_ED_VAL1.SetWindowText(_T("Hello"));

	/*Ū�����䤺�e*/
	//Way1���䤺�e�]�w��dir
	CString dir;
	CEdit *edit = (CEdit*)GetDlgItem(IDC_EDIT1);
	edit->GetWindowText(dir);
	
	//Way2�z�L�����ܼ�
	IDC_ED_VAL1.GetWindowText(dir);
	
}


void CA01_DIALOG::OnBnClickedOk()
{
	// TODO: Add your control notification handler code here
	CDialogEx::OnOK();
}


HBRUSH CA01_DIALOG::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor)
{
	HBRUSH hbr = CDialogEx::OnCtlColor(pDC, pWnd, nCtlColor);

	// TODO:  Change any attributes of the DC here
	switch (nCtlColor)
	{
	case CTLCOLOR_EDIT:
		switch (pWnd->GetDlgCtrlID())
		{
		case IDC_EDIT1:         
			pDC->SetBkColor(m_bluecolor);    
			pDC->SetTextColor(m_textcolor);
			hbr = (HBRUSH)m_bluebrush;
			break;
		default:
			hbr = CDialog::OnCtlColor(pDC, pWnd, nCtlColor);
			break;
		}
		break;
	}
	// TODO:  Return a different brush if the default is not desired
	return hbr;
}


BOOL CA01_DIALOG::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	// TODO:  Add extra initialization here
	m_redcolor = RGB(255, 0, 0);
	m_bluecolor = RGB(0, 0, 255);
	m_textcolor = RGB(255, 255, 255);
	m_redbrush.CreateSolidBrush(m_redcolor);
	m_bluebrush.CreateSolidBrush(m_bluecolor);
	return TRUE;  // return TRUE unless you set the focus to a control
				  // EXCEPTION: OCX Property Pages should return FALSE
}
