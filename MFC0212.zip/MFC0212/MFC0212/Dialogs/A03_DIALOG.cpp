// A03_DIALOG.cpp : implementation file
//

#include "stdafx.h"
#include "../MFC0212.h"
#include "A03_DIALOG.h"
#include "afxdialogex.h"
#include "../resource.h"


// CA03_DIALOG dialog

IMPLEMENT_DYNAMIC(CA03_DIALOG, CDialogEx)

CA03_DIALOG::CA03_DIALOG(CWnd* pParent /*=NULL*/)
	: CDialogEx(IDD_A03_DIALOG, pParent)
{

}

CA03_DIALOG::~CA03_DIALOG()
{
}

void CA03_DIALOG::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CA03_DIALOG, CDialogEx)
	ON_WM_CONTEXTMENU()
	ON_COMMAND(ID_POPUP_TP_OP_CLR, MnuTpOpHandler)
	//ON_COMMAND_RANGE(ID_POPUP_TP_OP_CLR, ID_POPUP_TP_OP_AND, CA03_DIALOG::MnuTpOpHandler)
END_MESSAGE_MAP()


// CA03_DIALOG message handlers


void CA03_DIALOG::OnContextMenu(CWnd* pWnd, CPoint point)
{
	CMenu mnuPopupOp;
	UINT nIDResource = IDR_MENU2;//menu resource id
	mnuPopupOp.LoadMenu(MAKEINTRESOURCE(nIDResource));
	//ScreenToClient(&point);//�qscreen point(�ù����W�I) �ন client point(Dialog View���W�I)

	// Get a pointer to the button
	CButton *pOpBtn;
	pOpBtn = reinterpret_cast<CButton *>(GetDlgItem(IDC_OP_BTN));

	// Find the rectangle around the button
	CRect rcOpBtn;
	pOpBtn->GetWindowRect(&rcOpBtn);

	// Get a pointer to the nPos submenu item of the menu
	int nPos = 0;//��0�hSubMenu
	CMenu* pmnuPopupOp = mnuPopupOp.GetSubMenu(nPos);//�^�ǫ���
	
	//pmnuPopupOp->EnableMenuItem(ID_POPUP_TP_OP_AND, MF_BYCOMMAND | MF_DISABLED | MF_GRAYED);
	//pmnuPopupOp->EnableMenuItem(ID_POPUP_TP_OP_OR, MF_BYCOMMAND | MF_DISABLED | MF_GRAYED);
	//pmnuPopupOp->EnableMenuItem(ID_POPUP_TP_OP_SHR, MF_BYCOMMAND | MF_DISABLED | MF_GRAYED);
	//pmnuPopupOp->EnableMenuItem(ID_POPUP_TP_OP_SHL, MF_BYCOMMAND | MF_DISABLED | MF_GRAYED);

	//Point in the button rectangle, display the context menu at left-bottom button
	if (rcOpBtn.PtInRect(point))
		pmnuPopupOp->TrackPopupMenu(TPM_LEFTALIGN | TPM_RIGHTBUTTON | TPM_RETURNCMD, rcOpBtn.left, rcOpBtn.bottom, this->GetParent());
}

void CA03_DIALOG::MnuTpOpHandler(/*UINT nID*/)
{
	//int nIndex = nID - ID_POPUP_TP_OP_CLR;
	/*if (nID == ID_POPUP_TP_OP_CLR)
	{
		MessageBox(NULL,L"ID_POPUP_TP_OP_CLR",NULL);
	}*/
	MessageBox(NULL, L"ID_POPUP_TP_OP_CLR", NULL);
}
