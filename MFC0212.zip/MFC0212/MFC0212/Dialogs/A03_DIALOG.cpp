// A03_DIALOG.cpp : implementation file
//

#include "stdafx.h"
#include "../MFC0212.h"
#include "A03_DIALOG.h"
#include "afxdialogex.h"
#include "../resource.h"


// CA03_DIALOG dialog

IMPLEMENT_DYNAMIC(CA03_DIALOG, CDialogEx)

CA03_DIALOG::CA03_DIALOG(CWnd* pParent /*=NULL*/)
	: CDialogEx(IDD_A03_DIALOG, pParent)
{

}

CA03_DIALOG::~CA03_DIALOG()
{
}

void CA03_DIALOG::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CA03_DIALOG, CDialogEx)
	ON_WM_CONTEXTMENU()
	ON_COMMAND_RANGE(ID_POPUP_TP_OP_ADD, ID_POPUP_TP_OP_CLR, CA03_DIALOG::MnuTpOprHandler)
	//ON_COMMAND(ID_POPUP_TP_OP_ADD, MnuTpOpHandler)
	ON_BN_CLICKED(IDC_OP_BTN, &CA03_DIALOG::OnBnClickedOpBtn)
END_MESSAGE_MAP()


// CA03_DIALOG message handlers


void CA03_DIALOG::OnContextMenu(CWnd* pWnd, CPoint point)
{
	CMenu mnuPopupOp;
	UINT nIDResource = IDR_MENU2;//menu resource id
	mnuPopupOp.LoadMenu(MAKEINTRESOURCE(nIDResource));
	//ScreenToClient(&point);//�qscreen point(�ù����W�I) �ন client point(Dialog View���W�I)

	// Get a pointer to the button
	CButton *pOpBtn;
	pOpBtn = reinterpret_cast<CButton *>(GetDlgItem(IDC_OP_BTN));

	// Find the rectangle around the button
	CRect rcOpBtn;
	pOpBtn->GetWindowRect(&rcOpBtn);

	// Get a pointer to the nPos submenu item of the menu
	int nPos = 0;//��0�hSubMenu
	CMenu* pmnuPopupOp = mnuPopupOp.GetSubMenu(nPos);//�^�ǫ���
	
	pmnuPopupOp->EnableMenuItem(ID_POPUP_TP_OP_AND, false ? MF_BYCOMMAND | MF_ENABLED : MF_BYCOMMAND | MF_DISABLED | MF_GRAYED);
	pmnuPopupOp->EnableMenuItem(ID_POPUP_TP_OP_OR, false ? MF_BYCOMMAND | MF_ENABLED : MF_BYCOMMAND | MF_DISABLED | MF_GRAYED);
	pmnuPopupOp->EnableMenuItem(ID_POPUP_TP_OP_SHR, false ? MF_BYCOMMAND | MF_ENABLED : MF_BYCOMMAND | MF_DISABLED | MF_GRAYED);
	pmnuPopupOp->EnableMenuItem(ID_POPUP_TP_OP_SHL, false ? MF_BYCOMMAND | MF_ENABLED : MF_BYCOMMAND | MF_DISABLED | MF_GRAYED);

	//Point in the button rectangle, display the context menu at left-bottom button
	if (rcOpBtn.PtInRect(point))
		pmnuPopupOp->TrackPopupMenu(TPM_LEFTALIGN | TPM_RIGHTBUTTON/* | TPM_RETURNCMD*/, rcOpBtn.left, rcOpBtn.bottom, this);
}



void CA03_DIALOG::MnuTpOprHandler(UINT nID)
{
	int nIndex = nID - ID_POPUP_TP_OP_CLR;

	switch (nID)
	{
	case ID_POPUP_TP_OP_ADD:
		AfxMessageBox(L"ID_POPUP_TP_OP_ADD");
		break;
	case ID_POPUP_TP_OP_DEC:
		AfxMessageBox(L"ID_POPUP_TP_OP_DEC");
		break;
	case ID_POPUP_TP_OP_MUL:
		AfxMessageBox(L"ID_POPUP_TP_OP_MUL");
		break;
	case ID_POPUP_TP_OP_DIV:
		AfxMessageBox(L"ID_POPUP_TP_OP_DIV");
		break;
	case ID_POPUP_TP_OP_AND:
		AfxMessageBox(L"ID_POPUP_TP_OP_AND");
		break;
	case ID_POPUP_TP_OP_OR:
		AfxMessageBox(L"ID_POPUP_TP_OP_OR");
		break;
	case ID_POPUP_TP_OP_SHR:
		AfxMessageBox(L"ID_POPUP_TP_OP_SHR");
		break;
	case ID_POPUP_TP_OP_SHL:
		AfxMessageBox(L"ID_POPUP_TP_OP_SHL");
		break;
	case ID_POPUP_TP_OP_CLR:
		AfxMessageBox(L"ID_POPUP_TP_OP_CLR");
		break;
	default:
		break;
	}
	
}




void CA03_DIALOG::OnBnClickedOpBtn()
{
	CMenu mnuPopupOp;
	UINT nIDResource = IDR_MENU2;//menu resource id
	mnuPopupOp.LoadMenu(MAKEINTRESOURCE(nIDResource));
	//ScreenToClient(&point);//�qscreen point(�ù����W�I) �ন client point(Dialog View���W�I)

	// Get a pointer to the button
	CButton *pOpBtn;
	pOpBtn = reinterpret_cast<CButton *>(GetDlgItem(IDC_OP_BTN));

	// Find the rectangle around the button
	CRect rcOpBtn;
	pOpBtn->GetWindowRect(&rcOpBtn);

	// Get a pointer to the nPos submenu item of the menu
	int nPos = 0;//��0�hSubMenu
	CMenu* pmnuPopupOp = mnuPopupOp.GetSubMenu(nPos);//�^�ǫ���

	pmnuPopupOp->EnableMenuItem(ID_POPUP_TP_OP_AND, false ? MF_BYCOMMAND | MF_ENABLED : MF_BYCOMMAND | MF_DISABLED | MF_GRAYED);
	pmnuPopupOp->EnableMenuItem(ID_POPUP_TP_OP_OR, false ? MF_BYCOMMAND | MF_ENABLED : MF_BYCOMMAND | MF_DISABLED | MF_GRAYED);
	pmnuPopupOp->EnableMenuItem(ID_POPUP_TP_OP_SHR, false ? MF_BYCOMMAND | MF_ENABLED : MF_BYCOMMAND | MF_DISABLED | MF_GRAYED);
	pmnuPopupOp->EnableMenuItem(ID_POPUP_TP_OP_SHL, false ? MF_BYCOMMAND | MF_ENABLED : MF_BYCOMMAND | MF_DISABLED | MF_GRAYED);

	//Point in the button rectangle, display the context menu at left-bottom button
	//if (rcOpBtn.PtInRect(point))
		pmnuPopupOp->TrackPopupMenu(TPM_LEFTALIGN | TPM_RIGHTBUTTON/* | TPM_RETURNCMD*/, rcOpBtn.left, rcOpBtn.bottom, this);
}
