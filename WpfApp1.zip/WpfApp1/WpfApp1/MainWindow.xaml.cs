﻿using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Windows;

namespace WpfApp1
{
    /// <summary>
    /// MainWindow.xaml 的互動邏輯
    /// </summary>
    public partial class MainWindow : Window
    {
        CategoryViewModel _viewModel = new CategoryViewModel();
        public MainWindow()
        {
            InitializeComponent();
            CategoryModel objCategoryModel = new CategoryModel();
            objCategoryModel.CategoryName = "aa";
            objCategoryModel.CategoryId = 1;
            _viewModel.SelectedCategory= objCategoryModel;

            ObservableCollection<CategoryModel> objCategories;
            objCategories = new ObservableCollection<CategoryModel>();
            objCategories.Add(objCategoryModel);
            _viewModel.Categories = objCategories;

            DataContext = _viewModel;
        }

        
    }

    public class CategoryViewModel : INotifyPropertyChanged
    {
        private CategoryModel _SelectedCategory;
        public CategoryModel SelectedCategory
        {
            get { return _SelectedCategory; }
            set
            {
                _SelectedCategory = value;
                OnPropertyChanged("SelectedCategory");
            }
        }

        private ObservableCollection<CategoryModel> _Categories;
        public ObservableCollection<CategoryModel> Categories
        {
            get { return _Categories; }
            set
            {
                _Categories = value;
                _Categories.Insert(0, new CategoryModel()
                {
                    CategoryId = 0,
                    CategoryName = " -- Select Category -- "
                });
                SelectedCategory = _Categories[0];
                OnPropertyChanged("Categories");

            }
        }

        protected virtual void OnPropertyChanged(string propertyName)
        {
            PropertyChangedEventHandler handler = PropertyChanged;
            if (handler != null) handler(this, new PropertyChangedEventArgs(propertyName));
        }

        public event PropertyChangedEventHandler PropertyChanged;
    }

    public class CategoryModel 
    {
        public int CategoryId { get; set; }
        public string CategoryName { get; set; }
    }    
}
