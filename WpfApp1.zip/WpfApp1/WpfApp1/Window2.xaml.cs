﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfApp1
{
    /// <summary>
    /// Window2.xaml 的互動邏輯
    /// </summary>
    public partial class Window2 : Window
    {
        public Window2()
        {
            InitializeComponent();
            this.lstItems.ItemsSource = GetItems();
        }

        public List<Options> MyOptions { get; set; }

        private List<Options> GetOptions()
        {
            List<Options> options = new List<Options>();
            options.Add(Options.Option1);
            options.Add(Options.Option2);

            return options;
        }

        private List<Selections> GetSelections()
        {
            List<Selections> selections = new List<Selections>();
            selections.Add(Selections.Selection1);
            selections.Add(Selections.Selection2);

            return selections;
        }

        private List<Item> GetItems()
        {
            List<Item> items = new List<Item>();
            items.Add(new Item() { SelectedOption = Options.Option1, AvailableOptions = GetOptions(), AvailableSelections = GetSelections() });
            items.Add(new Item() { SelectedOption = Options.Option2, AvailableOptions = GetOptions(), AvailableSelections = GetSelections() });

            return items;
        }
    }

    public class Item
    {
        public Options SelectedOption { get; set; }

        public Selections ChosenSelection { get; set; }
        public List<Options> AvailableOptions { get; set; }
        public List<Selections> AvailableSelections { get; set; }
    }

    public enum Options
    {
        Option1,
        Option2
    }

    public enum Selections
    {
        Selection1,
        Selection2
    }
}
